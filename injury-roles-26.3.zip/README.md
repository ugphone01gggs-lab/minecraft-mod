# Injury Roles

Co-op challenge mod คล้าย Blind Deaf Mute แต่เป็นอาการบาดเจ็บทางร่างกาย

## Roles

| Role | เอฟเฟกต์ |
|------|----------|
| **ขาหัก (Broken Leg)** | เดินช้าลง 45%, กระโดดต้องชาร์จ 1.5 วินาที (มีหลอด), ปีนบันไดช้า 30% |
| **แขนหัก (Broken Arm)** | ขุดช้า 45%, ดาเมจลด 50%, ใช้ได้แค่มือซ้าย |
| **ตาเบลอ (Blurred Vision)** | เบลอค่อย ๆ เพิ่มขึ้น, มีมึนงง + วูบวาบ, มีหมอกจำกัดระยะมอง |

## คำสั่ง (ต้องเป็น OP)

- `/injury set <player> <role>` — ตั้ง role (`broken_leg`, `broken_arm`, `blurred_vision`, `none`)
- `/injury get <player>` — ดู role
- `/injury clear <player>` — ล้าง role
- `/injury random` — สุ่ม role ให้ทุกคน
- `/injury list` — ดูรายชื่อผู้เล่นและ role

## ไอเท็มพิเศษ

- **ไม้เท้า (Crutch)** — คราฟจากไม้ (ช่วยลดโทษขาหักเมื่อถือ)
- **ผ้าพันแขน (Arm Sling)** — คราฟจากเส้นด้าย
- **ยาหยอดตา (Eye Drops)** — ขวดแก้ว + น้ำ + น้ำตาล
- **ผ้าพันแผล (Bandage)** — ขนสัตว์ขาว + เส้นด้าย

## การติดตั้ง

1. ติดตั้ง Fabric Loader สำหรับ Minecraft 26.2
2. ใส่ Fabric API + Fabric Language Kotlin
3. ใส่ไฟล์ jar ของ mod นี้ในโฟลเดอร์ mods ทั้ง server และ client

## หมายเหตุ

- ต้องติดตั้งทั้ง server และ client
- เน้นเล่น Multiplayer
- Animation และ texture บางส่วนยังเป็น placeholder (ต้องเพิ่ม texture เอง)

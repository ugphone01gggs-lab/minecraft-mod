# Wilderness Backport (26.3 → 26.2)

Mod สำหรับ Minecraft **26.2** ที่ลงทะเบียน content หลักจาก **26.3 Wilderness Bound** เพื่อให้ใช้กับ **ViaFabricPlus + Essential** ได้

## สิ่งที่ลงทะเบียนแล้ว
- Poplar Log / Planks / Stairs / Slab
- Red / Orange / Yellow Poplar Leaves
- Poplar Sapling (placeholder)
- Wool Stairs + Wool Slab ทุกสี (16 สี)
- Concrete Stairs + Concrete Slab ทุกสี (16 สี)

**Texture จะเป็น missing (ม่วงดำ)** ตามที่ขอ — เพราะยังไม่มี model จาก 26.3

## วิธีใช้
1. ติดตั้ง Java 25
2. เปิดโฟลเดอร์นี้ใน IDE หรือรัน `./gradlew build`
3. ไฟล์ jar จะอยู่ที่ `build/libs/wilderness-backport-1.0.0.jar`
4. ใส่ใน mods โฟลเดอร์ของ client 26.2 (พร้อม ViaFabricPlus + Essential)

## ข้อจำกัด
- ยังไม่มี recipe (สามารถเพิ่มด้วย datapack ได้)
- Cushion / Straw Bed / Shelf Mushroom / Red Shrub ยังไม่ได้ทำ (ต้องการ logic พิเศษ)
- พฤติกรรมพิเศษของ leaves / sapling ยังเป็น placeholder
- การ map ของ ViaFabricPlus อาจไม่สมบูรณ์ 100% สำหรับทุกกรณี

## ต่อไปที่ทำได้
- เพิ่ม recipe ผ่าน code หรือ datapack
- เพิ่ม Cushion (นั่งได้) และ Straw Bed
- ดึง texture จาก 26.3 มาทำ resource pack แยก


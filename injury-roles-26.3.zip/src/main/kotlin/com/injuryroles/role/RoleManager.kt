package com.injuryroles.role

import com.injuryroles.InjuryRoles
import com.injuryroles.network.ModNetworking
import net.fabricmc.fabric.api.entity.event.v1.ServerPlayerEvents
import net.fabricmc.fabric.api.networking.v1.ServerPlayConnectionEvents
import net.minecraft.server.level.ServerPlayer
import java.util.UUID
import java.util.concurrent.ConcurrentHashMap

object RoleManager {
    private val playerRoles = ConcurrentHashMap<UUID, InjuryRole>()

    fun register() {
        // เมื่อผู้เล่นเข้าเกม
        ServerPlayConnectionEvents.JOIN.register { handler, _, _ ->
            val player = handler.player
            val role = getRole(player)
            // ส่ง role ไปยัง client
            ModNetworking.sendRoleToClient(player, role)
        }

        // เมื่อผู้เล่นออกเกม
        ServerPlayConnectionEvents.DISCONNECT.register { handler, _ ->
            // เก็บ role ไว้ก็ได้ หรือลบก็ได้ ขึ้นกับความต้องการ
        }

        // เมื่อผู้เล่นตายแล้วเกิดใหม่ (รักษา role เดิม)
        ServerPlayerEvents.AFTER_RESPAWN.register { oldPlayer, newPlayer, _ ->
            val role = getRole(oldPlayer)
            setRole(newPlayer, role)
        }
    }

    fun getRole(player: ServerPlayer): InjuryRole {
        return playerRoles.getOrDefault(player.uuid, InjuryRole.NONE)
    }

    fun getRole(uuid: UUID): InjuryRole {
        return playerRoles.getOrDefault(uuid, InjuryRole.NONE)
    }

    fun setRole(player: ServerPlayer, role: InjuryRole) {
        playerRoles[player.uuid] = role
        ModNetworking.sendRoleToClient(player, role)
        InjuryRoles.LOGGER.info("Set role of ${player.scoreboardName} to ${role.id}")
    }

    fun clearRole(player: ServerPlayer) {
        setRole(player, InjuryRole.NONE)
    }

    fun getAllRoles(): Map<UUID, InjuryRole> = playerRoles.toMap()

    fun assignRandomRoles(players: List<ServerPlayer>) {
        val roles = listOf(
            InjuryRole.BROKEN_LEG,
            InjuryRole.BROKEN_ARM,
            InjuryRole.BLURRED_VISION
        )
        val shuffled = players.shuffled()
        shuffled.forEachIndexed { index, player ->
            val role = roles[index % roles.size]
            setRole(player, role)
        }
    }
}

package com.injuryroles.mixin;

import com.injuryroles.item.ModItems;
import com.injuryroles.role.InjuryRole;
import com.injuryroles.role.RoleManager;
import net.minecraft.resources.Identifier;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.ai.attributes.AttributeInstance;
import net.minecraft.world.entity.ai.attributes.AttributeModifier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(Player.class)
public class PlayerMixin {

    private static final Identifier BROKEN_LEG_SPEED = Identifier.fromNamespaceAndPath("injury-roles", "broken_leg_speed");
    private static final Identifier BROKEN_ARM_DAMAGE = Identifier.fromNamespaceAndPath("injury-roles", "broken_arm_damage");
    private static final Identifier BROKEN_ARM_MINING = Identifier.fromNamespaceAndPath("injury-roles", "broken_arm_mining");

    @Inject(method = "tick", at = @At("HEAD"))
    private void onTick(CallbackInfo ci) {
        Player self = (Player) (Object) this;
        if (!(self instanceof ServerPlayer serverPlayer)) return;

        InjuryRole role = RoleManager.INSTANCE.getRole(serverPlayer);

        // ===== Broken Leg: ลดความเร็ว 45% (ถือไม้เท้าเหลือ 20%) =====
        AttributeInstance speedAttr = serverPlayer.getAttribute(Attributes.MOVEMENT_SPEED);
        if (speedAttr != null) {
            speedAttr.removeModifier(BROKEN_LEG_SPEED);

            if (role == InjuryRole.BROKEN_LEG) {
                boolean holdingCrutch = isHolding(serverPlayer, ModItems.CRUTCH);
                double penalty = holdingCrutch ? -0.20 : -0.45;

                speedAttr.addTransientModifier(new AttributeModifier(
                        BROKEN_LEG_SPEED,
                        penalty,
                        AttributeModifier.Operation.ADD_MULTIPLIED_TOTAL
                ));
            }
        }

        // ===== Broken Arm: ลด attack damage =====
        AttributeInstance damageAttr = serverPlayer.getAttribute(Attributes.ATTACK_DAMAGE);
        if (damageAttr != null) {
            damageAttr.removeModifier(BROKEN_ARM_DAMAGE);
            if (role == InjuryRole.BROKEN_ARM) {
                boolean hasSling = isHolding(serverPlayer, ModItems.ARM_SLING);
                double penalty = hasSling ? -0.25 : -0.50;

                damageAttr.addTransientModifier(new AttributeModifier(
                        BROKEN_ARM_DAMAGE,
                        penalty,
                        AttributeModifier.Operation.ADD_MULTIPLIED_TOTAL
                ));
            }
        }

        // ===== Broken Arm: ลด mining efficiency =====
        try {
            AttributeInstance miningAttr = serverPlayer.getAttribute(Attributes.MINING_EFFICIENCY);
            if (miningAttr != null) {
                miningAttr.removeModifier(BROKEN_ARM_MINING);
                if (role == InjuryRole.BROKEN_ARM) {
                    boolean hasSling = isHolding(serverPlayer, ModItems.ARM_SLING);
                    double penalty = hasSling ? -0.20 : -0.45;

                    miningAttr.addTransientModifier(new AttributeModifier(
                            BROKEN_ARM_MINING,
                            penalty,
                            AttributeModifier.Operation.ADD_MULTIPLIED_TOTAL
                    ));
                }
            }
        } catch (Throwable ignored) {
            // mining_efficiency อาจไม่มีใน mapping บางเวอร์ชัน
        }
    }

    private static boolean isHolding(Player player, Item item) {
        return player.getMainHandItem().is(item) || player.getOffhandItem().is(item);
    }
}

package com.injuryroles.mixin;

import com.injuryroles.role.InjuryRole;
import com.injuryroles.role.RoleManager;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(LivingEntity.class)
public class LivingEntityMixin {

    // ลดความเร็วปีนบันไดสำหรับ Broken Leg (30% ช้าลง)
    @Inject(method = "getClimbingSpeed", at = @At("RETURN"), cancellable = true)
    private void modifyClimbingSpeed(CallbackInfoReturnable<Float> cir) {
        LivingEntity self = (LivingEntity) (Object) this;
        if (self instanceof ServerPlayer serverPlayer) {
            if (RoleManager.getRole(serverPlayer) == InjuryRole.BROKEN_LEG) {
                cir.setReturnValue(cir.getReturnValue() * 0.7f); // ช้าลง 30%
            }
        }
    }
}

package com.example.curse

/** อาการทั้ง 3 แบบ แต่ละแบบมีระดับ 1-3 */
enum class Ailment(val displayName: String) {
	LEG("ขาหัก"),
	ARM("แขนหัก"),
	BLUR("ตาเบลอ");
}

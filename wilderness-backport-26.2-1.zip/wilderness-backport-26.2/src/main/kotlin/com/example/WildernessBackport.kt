package com.example

import net.fabricmc.api.ModInitializer
import net.minecraft.resources.Identifier
import org.slf4j.LoggerFactory

object WildernessBackport : ModInitializer {
	const val MOD_ID: String = "wilderness-backport"

	val LOGGER = LoggerFactory.getLogger(MOD_ID)

	override fun onInitialize() {
		LOGGER.info("Wilderness Backport (26.3 content for 26.2) loading...")
		ModBlocks.register()
		LOGGER.info("Registered 26.3 blocks/items. Textures are intentionally missing.")
	}

	fun id(path: String): Identifier =
		Identifier.fromNamespaceAndPath(MOD_ID, path)

	/** Use vanilla namespace so ViaFabricPlus can map more cleanly */
	fun vanillaId(path: String): Identifier =
		Identifier.fromNamespaceAndPath("minecraft", path)
}

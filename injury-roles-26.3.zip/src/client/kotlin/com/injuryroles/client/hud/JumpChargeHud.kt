package com.injuryroles.client.hud

import com.injuryroles.network.ClientRoleHolder
import com.injuryroles.network.ModNetworking
import com.injuryroles.role.InjuryRole
import net.minecraft.client.Minecraft
import net.minecraft.client.gui.GuiGraphics
import net.minecraft.client.DeltaTracker

object JumpChargeHud {
    private const val CHARGE_TIME = 1.5f // วินาที
    private var chargeProgress = 0f
    private var isCharging = false
    private var wasJumpPressed = false
    private var jumpCooldown = 0 // ป้องกัน spam

    fun tick(client: Minecraft) {
        if (ClientRoleHolder.getRole() != InjuryRole.BROKEN_LEG) {
            chargeProgress = 0f
            isCharging = false
            jumpCooldown = 0
            return
        }

        if (jumpCooldown > 0) {
            jumpCooldown--
            return
        }

        val player = client.player ?: return
        val options = client.options
        val jumpPressed = options.keyJump.isDown

        // ต้องอยู่บนพื้นและไม่ได้อยู่ในน้ำ/บิน
        val canCharge = player.onGround() && !player.isInWater && !player.abilities.flying

        if (jumpPressed && canCharge) {
            if (!wasJumpPressed) {
                isCharging = true
                chargeProgress = 0f
            }
            if (isCharging) {
                chargeProgress += 1f / 20f / CHARGE_TIME
                if (chargeProgress >= 1f) {
                    chargeProgress = 1f
                    // ส่ง packet ไป server ให้กระโดด
                    ModNetworking.sendJumpCharge(true)
                    isCharging = false
                    chargeProgress = 0f
                    jumpCooldown = 10 // cooldown เล็กน้อย
                }
            }
        } else {
            // ปล่อยปุ่มกลางทาง → รีเซ็ต
            if (isCharging && chargeProgress > 0.05f) {
                // อาจจะมี feedback เล็กน้อย
            }
            isCharging = false
            chargeProgress = 0f
        }

        wasJumpPressed = jumpPressed
    }

    fun render(context: GuiGraphics, tickCounter: DeltaTracker) {
        if (!isCharging || chargeProgress <= 0f) return
        if (ClientRoleHolder.getRole() != InjuryRole.BROKEN_LEG) return

        val client = Minecraft.getInstance()
        val width = client.window.guiScaledWidth
        val height = client.window.guiScaledHeight

        val barWidth = 120
        val barHeight = 10
        val x = (width - barWidth) / 2
        val y = height / 2 + 36

        // เงา
        context.fill(x - 2, y - 2, x + barWidth + 2, y + barHeight + 2, 0x88000000.toInt())

        // พื้นหลังหลอด
        context.fill(x, y, x + barWidth, y + barHeight, 0xFF1a1a1a.toInt())

        // หลอด progress (ไล่สีจากส้ม → เขียว)
        val filled = (barWidth * chargeProgress).toInt().coerceIn(0, barWidth)
        val color = when {
            chargeProgress >= 0.95f -> 0xFF22cc22.toInt()
            chargeProgress >= 0.6f -> 0xFFccaa22.toInt()
            else -> 0xFFcc6622.toInt()
        }
        context.fill(x, y, x + filled, y + barHeight, color)

        // ขอบ
        context.fill(x, y, x + barWidth, y + 1, 0xFFffffff.toInt())
        context.fill(x, y + barHeight - 1, x + barWidth, y + barHeight, 0xFF666666.toInt())

        // ข้อความ
        val percent = (chargeProgress * 100).toInt()
        val text = if (chargeProgress >= 1f) "§aพร้อมกระโดด!" else "§eชาร์จกระโดด $percent%"
        val textWidth = client.font.width(text)
        context.drawString(client.font, text, (width - textWidth) / 2, y - 14, 0xFFFFFF, true)
    }

    /** เรียกจาก mixin เพื่อบล็อกการกระโดดปกติ */
    fun isChargingJump(): Boolean = isCharging || jumpCooldown > 0
}

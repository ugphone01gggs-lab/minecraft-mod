package com.example

import net.minecraft.core.Registry
import net.minecraft.core.registries.BuiltInRegistries
import net.minecraft.core.registries.Registries
import net.minecraft.resources.ResourceKey
import net.minecraft.world.item.BlockItem
import net.minecraft.world.item.Item
import net.minecraft.world.level.block.Block
import net.minecraft.world.level.block.Blocks
import net.minecraft.world.level.block.SlabBlock
import net.minecraft.world.level.block.SoundType
import net.minecraft.world.level.block.StairBlock
import net.minecraft.world.level.block.state.BlockBehaviour
import net.minecraft.world.level.block.state.properties.NoteBlockInstrument
import net.minecraft.world.level.material.MapColor
import net.minecraft.world.item.DyeColor
import net.minecraft.world.level.block.state.BlockState
import net.minecraft.world.entity.player.Player
import net.minecraft.world.InteractionResult
import net.minecraft.world.phys.BlockHitResult
import net.minecraft.core.BlockPos
import net.minecraft.world.level.Level
import net.minecraft.world.level.block.state.BlockBehaviour.Properties
import java.util.function.Function

/**
 * Registers a subset of 26.3 "Wilderness Bound" content on 26.2.
 * Includes basic cushions that can be sat on (simplified).
 */
object ModBlocks {

	// ============ Poplar wood set ============
	val POPLAR_LOG: Block = register(
		"poplar_log",
		{ props -> Block(props) },
		BlockBehaviour.Properties.of()
			.mapColor(MapColor.COLOR_BROWN)
			.instrument(NoteBlockInstrument.BASS)
			.strength(2.0f)
			.sound(SoundType.WOOD)
			.ignitedByLava()
	)

	val POPLAR_PLANKS: Block = register(
		"poplar_planks",
		{ props -> Block(props) },
		BlockBehaviour.Properties.of()
			.mapColor(MapColor.COLOR_LIGHT_GRAY)
			.instrument(NoteBlockInstrument.BASS)
			.strength(2.0f, 3.0f)
			.sound(SoundType.WOOD)
			.ignitedByLava()
	)

	val POPLAR_STAIRS: Block = register(
		"poplar_stairs",
		{ props -> StairBlock(POPLAR_PLANKS.defaultBlockState(), props) },
		BlockBehaviour.Properties.ofFullCopy(POPLAR_PLANKS)
	)

	val POPLAR_SLAB: Block = register(
		"poplar_slab",
		{ props -> SlabBlock(props) },
		BlockBehaviour.Properties.ofFullCopy(POPLAR_PLANKS)
	)

	val RED_POPLAR_LEAVES: Block = register(
		"red_poplar_leaves",
		{ props -> Block(props) },
		BlockBehaviour.Properties.of()
			.mapColor(MapColor.COLOR_RED)
			.strength(0.2f)
			.sound(SoundType.GRASS)
			.noOcclusion()
	)

	val ORANGE_POPLAR_LEAVES: Block = register(
		"orange_poplar_leaves",
		{ props -> Block(props) },
		BlockBehaviour.Properties.of()
			.mapColor(MapColor.COLOR_ORANGE)
			.strength(0.2f)
			.sound(SoundType.GRASS)
			.noOcclusion()
	)

	val YELLOW_POPLAR_LEAVES: Block = register(
		"yellow_poplar_leaves",
		{ props -> Block(props) },
		BlockBehaviour.Properties.of()
			.mapColor(MapColor.COLOR_YELLOW)
			.strength(0.2f)
			.sound(SoundType.GRASS)
			.noOcclusion()
	)

	val POPLAR_SAPLING: Block = register(
		"poplar_sapling",
		{ props -> Block(props) },
		BlockBehaviour.Properties.of()
			.mapColor(MapColor.PLANT)
			.noCollision()
			.instabreak()
			.sound(SoundType.GRASS)
	)

	// ============ Wool Stairs & Slabs ============
	val WOOL_STAIRS: Map<DyeColor, Block> = DyeColor.entries.associateWith { color ->
		register(
			"${color.serializedName}_wool_stairs",
			{ props -> StairBlock(Blocks.WHITE_WOOL.defaultBlockState(), props) },
			BlockBehaviour.Properties.of()
				.mapColor(color.mapColor)
				.strength(0.8f)
				.sound(SoundType.WOOL)
				.ignitedByLava()
		)
	}

	val WOOL_SLABS: Map<DyeColor, Block> = DyeColor.entries.associateWith { color ->
		register(
			"${color.serializedName}_wool_slab",
			{ props -> SlabBlock(props) },
			BlockBehaviour.Properties.of()
				.mapColor(color.mapColor)
				.strength(0.8f)
				.sound(SoundType.WOOL)
				.ignitedByLava()
		)
	}

	// ============ Concrete Stairs & Slabs ============
	val CONCRETE_STAIRS: Map<DyeColor, Block> = DyeColor.entries.associateWith { color ->
		register(
			"${color.serializedName}_concrete_stairs",
			{ props -> StairBlock(Blocks.WHITE_CONCRETE.defaultBlockState(), props) },
			BlockBehaviour.Properties.of()
				.mapColor(color.mapColor)
				.requiresCorrectToolForDrops()
				.strength(1.8f)
				.sound(SoundType.STONE)
		)
	}

	val CONCRETE_SLABS: Map<DyeColor, Block> = DyeColor.entries.associateWith { color ->
		register(
			"${color.serializedName}_concrete_slab",
			{ props -> SlabBlock(props) },
			BlockBehaviour.Properties.of()
				.mapColor(color.mapColor)
				.requiresCorrectToolForDrops()
				.strength(1.8f)
				.sound(SoundType.STONE)
		)
	}

	// ============ Cushions (simplified sit-able blocks) ============
	val CUSHIONS: Map<DyeColor, Block> = DyeColor.entries.associateWith { color ->
		register(
			"${color.serializedName}_cushion",
			{ props -> CushionBlock(props) },
			BlockBehaviour.Properties.of()
				.mapColor(color.mapColor)
				.strength(0.3f)
				.sound(SoundType.WOOL)
				.noOcclusion()
				.noCollision()
		)
	}

	fun register() {
		listOf(POPLAR_LOG, POPLAR_PLANKS, POPLAR_STAIRS, POPLAR_SLAB,
			RED_POPLAR_LEAVES, ORANGE_POPLAR_LEAVES, YELLOW_POPLAR_LEAVES, POPLAR_SAPLING)
		WOOL_STAIRS.values
		WOOL_SLABS.values
		CONCRETE_STAIRS.values
		CONCRETE_SLABS.values
		CUSHIONS.values
		WildernessBackport.LOGGER.info("Registered poplar + wool/concrete stairs/slabs + ${CUSHIONS.size} cushions")
	}

	private fun register(
		name: String,
		factory: Function<BlockBehaviour.Properties, Block>,
		properties: BlockBehaviour.Properties
	): Block {
		val id = WildernessBackport.vanillaId(name)
		val key = ResourceKey.create(Registries.BLOCK, id)
		val block = factory.apply(properties.setId(key))
		Registry.register(BuiltInRegistries.BLOCK, key, block)
		val itemKey = ResourceKey.create(Registries.ITEM, id)
		val item = BlockItem(block, Item.Properties().setId(itemKey))
		Registry.register(BuiltInRegistries.ITEM, itemKey, item)
		return block
	}
}

/**
 * Simplified cushion: right-click to sit (player pose / position adjust).
 * Not a full entity like vanilla, but usable.
 */
class CushionBlock(settings: Properties) : Block(settings) {
	override fun useWithoutItem(
		state: BlockState,
		level: Level,
		pos: BlockPos,
		player: Player,
		hit: BlockHitResult
	): InteractionResult {
		if (level.isClientSide) return InteractionResult.SUCCESS

		// Simple sit: move player slightly down and set pose if possible
		val sitPos = pos.above().center
		player.teleportTo(sitPos.x, pos.y + 0.3, sitPos.z)
		player.setShiftKeyDown(false)
		// Note: full sitting animation requires more entity/ride system work
		return InteractionResult.SUCCESS
	}
}

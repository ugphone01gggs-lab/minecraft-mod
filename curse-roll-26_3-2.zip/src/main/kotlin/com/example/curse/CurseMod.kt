package com.example.curse

import com.mojang.brigadier.arguments.IntegerArgumentType
import net.fabricmc.api.ModInitializer
import net.fabricmc.fabric.api.command.v2.CommandRegistrationCallback
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents
import net.fabricmc.fabric.api.event.player.UseItemCallback
import net.minecraft.commands.CommandSourceStack
import net.minecraft.commands.Commands
import net.minecraft.commands.arguments.EntityArgument
import net.minecraft.network.chat.Component
import net.minecraft.server.level.ServerPlayer
import net.minecraft.world.InteractionResult
import org.slf4j.LoggerFactory

object CurseMod : ModInitializer {
	const val MOD_ID = "curse-roll"
	private val LOGGER = LoggerFactory.getLogger(MOD_ID)

	override fun onInitialize() {
		ModItems.register()
		LOGGER.info("Curse Roll loading")

		// คลิกขวายาเพื่อใช้
		UseItemCallback.EVENT.register { player, world, hand ->
			val stack = player.getItemInHand(hand)
			val ailment = ModItems.ailmentOf(stack.item) ?: return@register InteractionResult.PASS
			if (world.isClientSide) return@register InteractionResult.SUCCESS
			if (player is ServerPlayer) {
				val (used, msg) = CurseManager.dose(player, ailment)
				player.displayClientMessage(Component.literal(msg), false)
				if (used && !player.isCreative) stack.shrink(1)
			}
			InteractionResult.SUCCESS
		}

		ServerTickEvents.END_SERVER_TICK.register { server ->
			server.playerList.players.forEach { CurseManager.tick(it) }
		}

		CommandRegistrationCallback.EVENT.register { dispatcher, _, _ ->
			dispatcher.register(
				Commands.literal("curse")
					.requires { it.hasPermission(2) }
					.then(
						Commands.literal("roll")
							.then(
								Commands.argument("targets", EntityArgument.players())
									.executes { ctx ->
										roll(ctx.source, EntityArgument.getPlayers(ctx, "targets"), null)
									}
									.then(
										Commands.argument("level", IntegerArgumentType.integer(1, 3))
											.executes { ctx ->
												roll(
													ctx.source,
													EntityArgument.getPlayers(ctx, "targets"),
													IntegerArgumentType.getInteger(ctx, "level")
												)
											}
									)
							)
					)
					.then(
						Commands.literal("clear")
							.then(
								Commands.argument("targets", EntityArgument.players())
									.executes { ctx ->
										EntityArgument.getPlayers(ctx, "targets").forEach { CurseManager.clear(it) }
										1
									}
							)
					)
			)
		}
	}

	private fun roll(source: CommandSourceStack, players: Collection<ServerPlayer>, level: Int?): Int {
		val started = CurseManager.startRolls(players.toList(), level)
		source.sendSuccess({ Component.literal("เริ่มสุ่มอาการให้ $started คน") }, true)
		return started
	}
}

package com.example.curse

import net.minecraft.core.Holder
import net.minecraft.network.chat.Component
import net.minecraft.resources.Identifier
import net.minecraft.server.level.ServerPlayer
import net.minecraft.world.entity.ai.attributes.Attribute
import net.minecraft.world.entity.ai.attributes.AttributeInstance
import net.minecraft.world.entity.ai.attributes.AttributeModifier
import net.minecraft.world.entity.ai.attributes.Attributes
import java.util.UUID
import kotlin.random.Random

class AilmentState(val ailment: Ailment, val level: Int) {
	/** เวลาที่เหลือ ใช้เฉพาะระดับ 1 ที่หายเองเมื่อหมดเวลา */
	var ticksLeft: Int = 20 * 180
	var doses: Int = 0
	var lastDoseTick: Long = -1_000_000L
	/** จำนวน tick ที่ยืนอยู่บนพื้นติดต่อกัน (ใช้กับการชาร์จกระโดดของขาหัก) */
	var groundTicks: Int = 0
}

private class PendingRoll(val ailment: Ailment, val level: Int) {
	var ticks: Int = 0
}

object CurseManager {
	const val DOSES_TO_CURE = 4
	const val DOSE_COOLDOWN_TICKS = 20L * 60 * 5
	private const val ROLL_TICKS = 90

	private val states = mutableMapOf<UUID, MutableMap<Ailment, AilmentState>>()
	private val pending = mutableMapOf<UUID, PendingRoll>()

	// ค่าผลกระทบแยกตามระดับ 1 2 3
	private val legSpeed = listOf(-0.25, -0.45, -0.65)
	private val legCharge = listOf(15, 30, 45)
	private val armDamage = listOf(-0.2, -0.4, -0.6)
	private val armSpeed = listOf(-0.25, -0.45, -0.65)

	fun stateOf(player: ServerPlayer, ailment: Ailment): AilmentState? =
		states[player.uuid]?.get(ailment)

	/**
	 * เริ่มสุ่มอาการให้ผู้เล่น ถ้ามีไม่เกิน 3 คน จะไม่ให้อาการซ้ำกันในรอบนั้น
	 * fixedLevel ใส่ระดับเองได้ ถ้าไม่ใส่จะสุ่ม 1-3
	 */
	fun startRolls(players: List<ServerPlayer>, fixedLevel: Int?): Int {
		val spread = players.size <= Ailment.entries.size
		val taken = mutableSetOf<Ailment>()
		var started = 0
		for (p in players) {
			if (pending.containsKey(p.uuid)) continue
			val free = Ailment.entries.filter { stateOf(p, it) == null && (!spread || it !in taken) }
			if (free.isEmpty()) continue
			val ailment = free.random()
			if (spread) taken += ailment
			pending[p.uuid] = PendingRoll(ailment, fixedLevel ?: Random.nextInt(1, 4))
			started++
		}
		return started
	}

	fun clear(player: ServerPlayer) {
		states.remove(player.uuid)
		pending.remove(player.uuid)
		applyAll(player, emptyMap())
	}

	/** ใช้ยา คืนค่า (ใช้ไปแล้วหรือไม่, ข้อความที่จะแสดง) */
	fun dose(player: ServerPlayer, ailment: Ailment): Pair<Boolean, String> {
		val s = stateOf(player, ailment) ?: return false to "คุณไม่มี${ailment.displayName}"
		val now = player.level().gameTime
		val wait = DOSE_COOLDOWN_TICKS - (now - s.lastDoseTick)
		if (wait > 0) {
			return false to "ต้องรออีก ${(wait + 19) / 20} วินาทีก่อนใช้ยาครั้งถัดไป"
		}
		s.doses++
		s.lastDoseTick = now
		if (s.doses >= DOSES_TO_CURE) {
			states[player.uuid]?.remove(ailment)
			applyAll(player, states[player.uuid] ?: emptyMap())
			return true to "รักษา${ailment.displayName}หายแล้ว"
		}
		return true to "ใช้ยา${ailment.displayName}แล้ว ${s.doses}/$DOSES_TO_CURE ครั้ง"
	}

	/** เรียกทุก tick ของเซิร์ฟเวอร์ */
	fun tick(player: ServerPlayer) {
		pending[player.uuid]?.let { tickRoll(player, it) }

		val map = states[player.uuid] ?: return
		for (s in map.values.toList()) {
			if (s.level == 1 && s.doses == 0) {
				s.ticksLeft--
				if (s.ticksLeft <= 0) {
					map.remove(s.ailment)
					player.displayClientMessage(Component.literal("${s.ailment.displayName}หายแล้ว"), false)
				}
			}
		}

		val leg = map[Ailment.LEG]
		if (leg != null) {
			leg.groundTicks = if (player.onGround()) leg.groundTicks + 1 else 0
		}

		if (map.isEmpty()) states.remove(player.uuid)
		applyAll(player, map)
	}

	private fun tickRoll(player: ServerPlayer, roll: PendingRoll) {
		roll.ticks++
		if (roll.ticks < ROLL_TICKS) {
			// ช่วงสุ่ม: แสดงชื่ออาการสุ่มไปเรื่อย ๆ และค่อย ๆ ช้าลง
			val step = 2 + roll.ticks / 25
			if (roll.ticks % step == 0) {
				val shown = Ailment.entries.random()
				player.displayClientMessage(Component.literal("กำลังสุ่ม... ${shown.displayName}"), true)
			}
			return
		}
		pending.remove(player.uuid)
		val map = states.getOrPut(player.uuid) { mutableMapOf() }
		map[roll.ailment] = AilmentState(roll.ailment, roll.level)
		applyAll(player, map)
		player.displayClientMessage(
			Component.literal("ได้รับ: ${roll.ailment.displayName} ระดับ ${roll.level}"),
			false
		)
	}

	private fun applyAll(player: ServerPlayer, map: Map<Ailment, AilmentState>) {
		val leg = map[Ailment.LEG]
		val arm = map[Ailment.ARM]

		// ขาหัก: เดินช้าลง และต้องชาร์จก่อนกระโดด (ยังไม่ชาร์จจะกระโดดไม่ได้)
		setMod(player, Attributes.MOVEMENT_SPEED, id("leg_speed"),
			leg?.let { legSpeed[it.level - 1] })
		val charging = leg != null && player.onGround() && leg.groundTicks < legCharge[leg.level - 1]
		setMod(player, Attributes.JUMP_STRENGTH, id("leg_jump"), if (charging) -1.0 else null)

		// แขนหัก: ตีเบาลงและตีช้าลง รวมถึงขุดช้าลง
		setMod(player, Attributes.ATTACK_DAMAGE, id("arm_damage"),
			arm?.let { armDamage[it.level - 1] })
		setMod(player, Attributes.ATTACK_SPEED, id("arm_speed"),
			arm?.let { armSpeed[it.level - 1] })
		setMod(player, Attributes.BLOCK_BREAK_SPEED, id("arm_break"),
			arm?.let { armSpeed[it.level - 1] })
	}

	private fun id(name: String): Identifier =
		Identifier.fromNamespaceAndPath(CurseMod.MOD_ID, name)

	private fun setMod(player: ServerPlayer, attr: Holder<Attribute>, id: Identifier, amount: Double?) {
		val inst: AttributeInstance = player.getAttribute(attr) ?: return
		if (amount == null) {
			inst.removeModifier(id)
		} else {
			inst.addOrUpdateTransientModifier(
				AttributeModifier(id, amount, AttributeModifier.Operation.ADD_MULTIPLIED_TOTAL)
			)
		}
	}
}

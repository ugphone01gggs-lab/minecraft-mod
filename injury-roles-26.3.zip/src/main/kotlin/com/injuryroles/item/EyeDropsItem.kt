package com.injuryroles.item

import com.injuryroles.network.ClientRoleHolder
import com.injuryroles.role.InjuryRole
import net.minecraft.network.chat.Component
import net.minecraft.server.level.ServerPlayer
import net.minecraft.world.InteractionHand
import net.minecraft.world.InteractionResult
import net.minecraft.world.entity.player.Player
import net.minecraft.world.item.Item
import net.minecraft.world.item.ItemStack
import net.minecraft.world.level.Level

class EyeDropsItem(properties: Properties) : Item(properties) {

    override fun use(level: Level, player: Player, hand: InteractionHand): InteractionResult {
        val stack = player.getItemInHand(hand)

        if (!level.isClientSide && player is ServerPlayer) {
            // ใช้แล้วลด blur ชั่วคราว (ผ่าน packet หรือ data)
            // ตอนนี้แค่แจ้งเตือน
            player.sendSystemMessage(Component.literal("§aใช้ยาหยอดตาแล้ว! อาการเบลอลดลงชั่วคราว"))
            stack.shrink(1)
            return InteractionResult.SUCCESS
        }

        return InteractionResult.CONSUME
    }
}

package com.injuryroles.network

import com.injuryroles.InjuryRoles
import com.injuryroles.role.InjuryRole
import com.injuryroles.role.RoleManager
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking
import net.fabricmc.fabric.api.networking.v1.PayloadTypeRegistry
import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking
import net.minecraft.network.RegistryFriendlyByteBuf
import net.minecraft.network.codec.StreamCodec
import net.minecraft.network.protocol.common.custom.CustomPacketPayload
import net.minecraft.server.level.ServerPlayer
import net.minecraft.world.entity.player.Player

object ModNetworking {
    // Payload สำหรับส่ง role ไป client
    data class RoleSyncPayload(val roleId: String) : CustomPacketPayload {
        override fun type(): CustomPacketPayload.Type<RoleSyncPayload> = TYPE

        companion object {
            val TYPE = CustomPacketPayload.Type<RoleSyncPayload>(InjuryRoles.id("role_sync"))
            val CODEC: StreamCodec<RegistryFriendlyByteBuf, RoleSyncPayload> = StreamCodec.of(
                { buf, payload -> buf.writeUtf(payload.roleId) },
                { buf -> RoleSyncPayload(buf.readUtf()) }
            )
        }
    }

    // Payload สำหรับ jump charge จาก client -> server
    data class JumpChargePayload(val charged: Boolean) : CustomPacketPayload {
        override fun type(): CustomPacketPayload.Type<JumpChargePayload> = TYPE

        companion object {
            val TYPE = CustomPacketPayload.Type<JumpChargePayload>(InjuryRoles.id("jump_charge"))
            val CODEC: StreamCodec<RegistryFriendlyByteBuf, JumpChargePayload> = StreamCodec.of(
                { buf, payload -> buf.writeBoolean(payload.charged) },
                { buf -> JumpChargePayload(buf.readBoolean()) }
            )
        }
    }

    fun register() {
        PayloadTypeRegistry.playS2C().register(RoleSyncPayload.TYPE, RoleSyncPayload.CODEC)
        PayloadTypeRegistry.playC2S().register(JumpChargePayload.TYPE, JumpChargePayload.CODEC)

        // Server รับ jump charge
        ServerPlayNetworking.registerGlobalReceiver(JumpChargePayload.TYPE) { payload, context ->
            val player = context.player()
            if (RoleManager.getRole(player) == InjuryRole.BROKEN_LEG && payload.charged) {
                // อนุญาตให้กระโดดได้ (server จะจัดการ logic กระโดด)
                player.jumpFromGround()
            }
        }
    }

    fun registerClient() {
        ClientPlayNetworking.registerGlobalReceiver(RoleSyncPayload.TYPE) { payload, _ ->
            ClientRoleHolder.setRole(InjuryRole.fromId(payload.roleId))
        }
    }

    fun sendRoleToClient(player: ServerPlayer, role: InjuryRole) {
        ServerPlayNetworking.send(player, RoleSyncPayload(role.id))
    }

    fun sendJumpCharge(charged: Boolean) {
        ClientPlayNetworking.send(JumpChargePayload(charged))
    }
}

/** เก็บ role ฝั่ง client */
object ClientRoleHolder {
    private var currentRole: InjuryRole = InjuryRole.NONE

    fun setRole(role: InjuryRole) {
        currentRole = role
    }

    fun getRole(): InjuryRole = currentRole

    fun hasRole(role: InjuryRole): Boolean = currentRole == role
}

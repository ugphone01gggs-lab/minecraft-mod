package com.injuryroles

import com.injuryroles.command.InjuryCommands
import com.injuryroles.effect.InjuryEffects
import com.injuryroles.item.ModItems
import com.injuryroles.network.ModNetworking
import com.injuryroles.role.RoleManager
import net.fabricmc.api.ModInitializer
import net.minecraft.resources.Identifier
import org.slf4j.LoggerFactory

object InjuryRoles : ModInitializer {
    const val MOD_ID: String = "injury-roles"

    val LOGGER = LoggerFactory.getLogger(MOD_ID)

    override fun onInitialize() {
        LOGGER.info("Injury Roles mod initializing...")

        ModItems.register()
        ModNetworking.register()
        RoleManager.register()
        InjuryCommands.register()
        InjuryEffects.register()

        LOGGER.info("Injury Roles mod loaded!")
    }

    fun id(path: String): Identifier =
        Identifier.fromNamespaceAndPath(MOD_ID, path)
}

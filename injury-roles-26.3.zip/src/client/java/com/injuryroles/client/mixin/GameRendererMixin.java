package com.injuryroles.client.mixin;

import com.injuryroles.client.render.VisionEffects;
import com.injuryroles.network.ClientRoleHolder;
import com.injuryroles.role.InjuryRole;
import net.minecraft.client.renderer.GameRenderer;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(GameRenderer.class)
public class GameRendererMixin {

    // สามารถ inject เพื่อเพิ่ม blur / nausea effect ได้ที่นี่
    // ในเวอร์ชันนี้ใช้ VisionEffects แทนเป็นหลัก
}

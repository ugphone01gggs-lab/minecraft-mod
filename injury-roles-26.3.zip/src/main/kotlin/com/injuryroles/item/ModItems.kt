package com.injuryroles.item

import com.injuryroles.InjuryRoles
import net.minecraft.core.Registry
import net.minecraft.core.registries.BuiltInRegistries
import net.minecraft.core.registries.Registries
import net.minecraft.network.chat.Component
import net.minecraft.resources.ResourceKey
import net.minecraft.world.item.CreativeModeTab
import net.minecraft.world.item.Item
import net.minecraft.world.item.ItemStack

object ModItems {
    // ไม้เท้าช่วยเดิน (ลดโทษขาหักเมื่อถือ)
    @JvmField
    val CRUTCH: Item = register("crutch", Item(Item.Properties().stacksTo(1)))

    // ผ้าพันแขน (ลดโทษแขนหักเมื่อถือ)
    @JvmField
    val ARM_SLING: Item = register("arm_sling", Item(Item.Properties().stacksTo(1)))

    // ยาหยอดตา (ลดโทษตาเบลอชั่วคราว)
    @JvmField
    val EYE_DROPS: Item = register("eye_drops", EyeDropsItem(Item.Properties().stacksTo(16)))

    // ผ้าพันแผลทั่วไป
    @JvmField
    val BANDAGE: Item = register("bandage", Item(Item.Properties().stacksTo(16)))

    private fun register(name: String, item: Item): Item {
        return Registry.register(BuiltInRegistries.ITEM, InjuryRoles.id(name), item)
    }

    fun register() {
        val tabKey = ResourceKey.create(Registries.CREATIVE_MODE_TAB, InjuryRoles.id("main"))
        Registry.register(BuiltInRegistries.CREATIVE_MODE_TAB, tabKey,
            CreativeModeTab.builder()
                .title(Component.translatable("itemGroup.injury-roles.main"))
                .icon { ItemStack(CRUTCH) }
                .displayItems { _, output ->
                    output.accept(CRUTCH)
                    output.accept(ARM_SLING)
                    output.accept(EYE_DROPS)
                    output.accept(BANDAGE)
                }
                .build()
        )

        InjuryRoles.LOGGER.info("Registered mod items")
    }
}

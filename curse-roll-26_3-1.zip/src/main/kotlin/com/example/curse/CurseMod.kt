package com.example.curse

import com.mojang.brigadier.arguments.StringArgumentType
import net.fabricmc.api.ModInitializer
import net.fabricmc.fabric.api.command.v2.CommandRegistrationCallback
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents
import net.fabricmc.fabric.api.entity.event.v1.ServerLivingEntityEvents
import net.minecraft.commands.CommandSourceStack
import net.minecraft.commands.Commands
import net.minecraft.commands.arguments.EntityArgument
import net.minecraft.server.level.ServerPlayer
import org.slf4j.LoggerFactory

object CurseMod : ModInitializer {
	const val MOD_ID = "curse-roll"
	private val LOGGER = LoggerFactory.getLogger(MOD_ID)
	private var extraHit = false
	private val level get() = CurseManager.level

	override fun onInitialize() {
		LOGGER.info("Curse Roll loading")

		ServerLivingEntityEvents.AFTER_DAMAGE.register { entity, source, _, damageTaken, _ ->
			if (entity is ServerPlayer && !extraHit && CurseManager.has(entity, Curse.FRAGILE)) {
				extraHit = true
				try {
					entity.hurt(source, damageTaken * 0.5f * level.severity.toFloat())
				} finally {
					extraHit = false
				}
			}
		}

		ServerTickEvents.END_SERVER_TICK.register { server ->
			server.playerList.players.forEach { CurseManager.tick(it) }
		}

		CommandRegistrationCallback.EVENT.register { dispatcher, _, _ ->
			dispatcher.register(
				Commands.literal("curse")
					.requires { it.hasPermission(2) }
					.then(
						Commands.literal("roll")
							.then(
								Commands.argument("targets", EntityArgument.players())
									.executes { ctx ->
										val players = EntityArgument.getPlayers(ctx, "targets")
										players.forEach { p ->
											val rolled = CurseManager.roll(p)
											val msg = if (rolled == null) {
												"${p.name.string} มีอาการครบทุกอย่างแล้ว"
											} else {
												"${p.name.string} ได้รับอาการ: ${rolled.displayName}"
											}
											ctx.source.sendSuccess({ net.minecraft.network.chat.Component.literal(msg) }, true)
										}
										players.size
									}
							)
					)
					.then(
						Commands.literal("level")
							.then(
								Commands.argument("level", StringArgumentType.word())
									.suggests { _, b -> net.minecraft.commands.SharedSuggestionProvider.suggest(Level.entries.map { it.name.lowercase() }, b) }
									.executes { ctx ->
										val raw = StringArgumentType.getString(ctx, "level")
										val picked = Level.parse(raw)
										if (picked == null) {
											ctx.source.sendFailure(net.minecraft.network.chat.Component.literal("ระดับไม่ถูกต้อง ใช้ mild, normal หรือ harsh"))
											0
										} else {
											CurseManager.level = picked
											ctx.source.sendSuccess({ net.minecraft.network.chat.Component.literal("ตั้งระดับเป็น ${picked.displayName}") }, true)
											1
										}
									}
							)
					)
					.then(
						Commands.literal("clear")
							.then(
								Commands.argument("targets", EntityArgument.players())
									.executes { ctx ->
										val players = EntityArgument.getPlayers(ctx, "targets")
										players.forEach { CurseManager.clear(it) }
										players.size
									}
							)
					)
			)
		}
	}
}

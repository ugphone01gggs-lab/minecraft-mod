package com.injuryroles.command

import com.injuryroles.role.InjuryRole
import com.injuryroles.role.RoleManager
import com.mojang.brigadier.arguments.StringArgumentType
import net.fabricmc.fabric.api.command.v2.CommandRegistrationCallback
import net.minecraft.commands.Commands
import net.minecraft.commands.arguments.EntityArgument
import net.minecraft.network.chat.Component
import net.minecraft.server.level.ServerPlayer

object InjuryCommands {
    fun register() {
        CommandRegistrationCallback.EVENT.register { dispatcher, _, _ ->
            dispatcher.register(
                Commands.literal("injury")
                    .requires { it.hasPermission(2) }
                    .then(
                        Commands.literal("set")
                            .then(
                                Commands.argument("player", EntityArgument.player())
                                    .then(
                                        Commands.argument("role", StringArgumentType.word())
                                            .suggests { _, builder ->
                                                InjuryRole.entries.forEach { builder.suggest(it.id) }
                                                builder.buildFuture()
                                            }
                                            .executes { ctx ->
                                                val player = EntityArgument.getPlayer(ctx, "player")
                                                val roleId = StringArgumentType.getString(ctx, "role")
                                                val role = InjuryRole.fromId(roleId)
                                                RoleManager.setRole(player, role)
                                                ctx.source.sendSuccess(
                                                    { Component.literal("§aตั้ง role ของ ${player.scoreboardName} เป็น §e${role.displayName}") },
                                                    true
                                                )
                                                1
                                            }
                                    )
                            )
                    )
                    .then(
                        Commands.literal("get")
                            .then(
                                Commands.argument("player", EntityArgument.player())
                                    .executes { ctx ->
                                        val player = EntityArgument.getPlayer(ctx, "player")
                                        val role = RoleManager.getRole(player)
                                        ctx.source.sendSuccess(
                                            { Component.literal("§b${player.scoreboardName} §fมี role: §e${role.displayName} §7(${role.description})") },
                                            false
                                        )
                                        1
                                    }
                            )
                    )
                    .then(
                        Commands.literal("clear")
                            .then(
                                Commands.argument("player", EntityArgument.player())
                                    .executes { ctx ->
                                        val player = EntityArgument.getPlayer(ctx, "player")
                                        RoleManager.clearRole(player)
                                        ctx.source.sendSuccess(
                                            { Component.literal("§aล้าง role ของ ${player.scoreboardName} แล้ว") },
                                            true
                                        )
                                        1
                                    }
                            )
                    )
                    .then(
                        Commands.literal("random")
                            .executes { ctx ->
                                val server = ctx.source.server
                                val players = server.playerList.players
                                if (players.isEmpty()) {
                                    ctx.source.sendFailure(Component.literal("ไม่มีผู้เล่นในเซิร์ฟเวอร์"))
                                    return@executes 0
                                }
                                RoleManager.assignRandomRoles(players)
                                ctx.source.sendSuccess(
                                    { Component.literal("§aสุ่ม role ให้ผู้เล่นทั้งหมดแล้ว (${players.size} คน)") },
                                    true
                                )
                                1
                            }
                    )
                    .then(
                        Commands.literal("list")
                            .executes { ctx ->
                                val roles = RoleManager.getAllRoles()
                                if (roles.isEmpty()) {
                                    ctx.source.sendSuccess({ Component.literal("§7ยังไม่มีใครมี role") }, false)
                                } else {
                                    val server = ctx.source.server
                                    roles.forEach { (uuid, role) ->
                                        val name = server.playerList.getPlayer(uuid)?.scoreboardName ?: uuid.toString()
                                        ctx.source.sendSuccess(
                                            { Component.literal("§e$name §7→ §b${role.displayName}") },
                                            false
                                        )
                                    }
                                }
                                1
                            }
                    )
            )
        }
    }
}

package com.injuryroles.effect

import com.injuryroles.item.ModItems
import com.injuryroles.role.InjuryRole
import com.injuryroles.role.RoleManager
import net.fabricmc.fabric.api.event.player.AttackBlockCallback
import net.fabricmc.fabric.api.event.player.AttackEntityCallback
import net.fabricmc.fabric.api.event.player.UseItemCallback
import net.minecraft.network.chat.Component
import net.minecraft.server.level.ServerPlayer
import net.minecraft.world.InteractionHand
import net.minecraft.world.InteractionResult
import net.minecraft.world.entity.EquipmentSlot

object InjuryEffects {

    fun register() {
        // Broken Arm: จำกัดการใช้มือขวา (Main Hand)
        // ถ้าใช้มือขวาโจมตี/ใช้ของ → แจ้งเตือนและลดประสิทธิภาพ (attribute จัดการแล้ว)

        UseItemCallback.EVENT.register { player, world, hand ->
            if (player is ServerPlayer && RoleManager.getRole(player) == InjuryRole.BROKEN_ARM) {
                if (hand == InteractionHand.MAIN_HAND) {
                    // อนุญาตแต่จะช้า/อ่อนแอ เพราะ attribute
                    // ถ้าอยากบล็อกเด็ดขาด สามารถ return FAIL ได้
                    // ตอนนี้ปล่อยผ่าน แต่จะมีข้อความเตือนครั้งแรก
                }
            }
            InteractionResult.PASS
        }

        AttackEntityCallback.EVENT.register { player, world, hand, entity, hitResult ->
            if (player is ServerPlayer && RoleManager.getRole(player) == InjuryRole.BROKEN_ARM) {
                if (hand == InteractionHand.MAIN_HAND) {
                    // ดาเมจถูกลดผ่าน attribute แล้ว
                }
            }
            InteractionResult.PASS
        }

        AttackBlockCallback.EVENT.register { player, world, hand, pos, direction ->
            if (player is ServerPlayer && RoleManager.getRole(player) == InjuryRole.BROKEN_ARM) {
                // mining speed ถูกลดผ่าน attribute
            }
            InteractionResult.PASS
        }
    }
}

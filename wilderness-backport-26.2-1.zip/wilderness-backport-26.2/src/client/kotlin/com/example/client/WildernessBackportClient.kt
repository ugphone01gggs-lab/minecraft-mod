package com.example.client

import net.fabricmc.api.ClientModInitializer
import org.slf4j.LoggerFactory

object WildernessBackportClient : ClientModInitializer {
	private val LOGGER = LoggerFactory.getLogger("wilderness-backport")

	override fun onInitializeClient() {
		LOGGER.info("Wilderness Backport client side ready (no special client logic yet)")
	}
}

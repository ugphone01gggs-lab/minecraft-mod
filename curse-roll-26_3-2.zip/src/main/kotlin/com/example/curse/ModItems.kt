package com.example.curse

import net.minecraft.core.Registry
import net.minecraft.core.registries.BuiltInRegistries
import net.minecraft.core.registries.Registries
import net.minecraft.resources.Identifier
import net.minecraft.resources.ResourceKey
import net.minecraft.world.item.Item

/** ยารักษาอาการ คราฟได้จาก recipe ใน datapack ของ mod */
object ModItems {
	val LEG_MEDICINE: Item = register("leg_medicine")
	val ARM_MEDICINE: Item = register("arm_medicine")
	val BLUR_MEDICINE: Item = register("blur_medicine")

	/** เรียกเพื่อให้ object นี้โหลดและลงทะเบียนไอเทม */
	fun register() {}

	fun ailmentOf(item: Item): Ailment? = when (item) {
		LEG_MEDICINE -> Ailment.LEG
		ARM_MEDICINE -> Ailment.ARM
		BLUR_MEDICINE -> Ailment.BLUR
		else -> null
	}

	private fun register(name: String): Item {
		val id = Identifier.fromNamespaceAndPath(CurseMod.MOD_ID, name)
		val key = ResourceKey.create(Registries.ITEM, id)
		val item = Item(Item.Properties().setId(key).stacksTo(16))
		return Registry.register(BuiltInRegistries.ITEM, key, item)
	}
}

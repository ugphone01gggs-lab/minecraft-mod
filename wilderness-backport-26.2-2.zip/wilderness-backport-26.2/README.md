# Wilderness Backport (26.3 → 26.2) v1.1

ลงทะเบียน content จาก 26.3 ลง 26.2 + texture ง่าย ๆ + Cushion นั่งได้แบบพื้นฐาน

## สิ่งที่มี
- Poplar Log / Planks / Stairs / Slab / Leaves / Sapling
- Wool Stairs + Slab ทุกสี
- Concrete Stairs + Slab ทุกสี
- **Cushion ทุกสี** (คลิกขวาแล้วนั่งได้แบบง่าย + มี texture)

## หมายเหตุ
- Cushion เป็นเวอร์ชันง่าย (บล็อก) ไม่ใช่ Entity แบบ vanilla เต็ม ๆ
- Texture เป็นแบบที่สร้างขึ้นมาเอง (สีใกล้เคียง แต่ลายไม่เหมือนของแท้)
- ยังไม่มี recipe
- ต้องใช้กับ ViaFabricPlus

## Build
```bash
./gradlew build
```
jar อยู่ที่ build/libs/

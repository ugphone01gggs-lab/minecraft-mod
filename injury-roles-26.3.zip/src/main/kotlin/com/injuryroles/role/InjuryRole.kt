package com.injuryroles.role

enum class InjuryRole(val id: String, val displayName: String, val description: String) {
    NONE("none", "ไม่มี", "ไม่มีอาการบาดเจ็บ"),
    BROKEN_LEG("broken_leg", "ขาหัก", "เดินช้า กระโดดต้องชาร์จ ปีนช้า"),
    BROKEN_ARM("broken_arm", "แขนหัก", "ขุดช้า ดาเมจลด ใช้ได้แค่มือซ้าย"),
    BLURRED_VISION("blurred_vision", "ตาเบลอ", "เบลอค่อย ๆ เพิ่มขึ้น มีหมอกและมึนงง");

    companion object {
        fun fromId(id: String): InjuryRole =
            entries.find { it.id == id } ?: NONE
    }
}

package com.injuryroles.client.render

import com.injuryroles.network.ClientRoleHolder
import com.injuryroles.role.InjuryRole
import net.minecraft.client.Minecraft
import kotlin.math.sin

object VisionEffects {
    private var blurIntensity = 0f
    private var dizzinessTimer = 0f
    private var flashTimer = 0f
    private var temporaryRelief = 0 // ticks ที่ยาหยอดตาทำงาน

    fun register() {
        // พร้อมสำหรับขยายเป็น shader ภายหลัง
    }

    fun tick(client: Minecraft) {
        if (ClientRoleHolder.getRole() != InjuryRole.BLURRED_VISION) {
            blurIntensity = 0f
            dizzinessTimer = 0f
            flashTimer = 0f
            temporaryRelief = 0
            return
        }

        if (temporaryRelief > 0) {
            temporaryRelief--
            // ตอนมียา → เบลอลดลง
            if (blurIntensity > 0.2f) blurIntensity -= 0.01f
        } else {
            // เบลอค่อย ๆ เพิ่มขึ้นจนถึงค่าสูงสุด
            if (blurIntensity < 1f) {
                blurIntensity += 0.0006f
            }
        }

        dizzinessTimer += 0.04f
        flashTimer += 0.08f
    }

    fun applyEyeDropsRelief(durationTicks: Int = 20 * 30) { // 30 วินาที
        temporaryRelief = durationTicks
        blurIntensity = (blurIntensity * 0.4f).coerceAtMost(0.3f)
    }

    fun getBlurIntensity(): Float = blurIntensity

    fun getDizzinessOffset(): Float {
        if (ClientRoleHolder.getRole() != InjuryRole.BLURRED_VISION) return 0f
        return sin(dizzinessTimer.toDouble()).toFloat() * 4f * blurIntensity
    }

    fun getFlashAlpha(): Float {
        if (ClientRoleHolder.getRole() != InjuryRole.BLURRED_VISION) return 0f
        val wave = (sin(flashTimer * 0.6) + 1.0) / 2.0
        return if (wave > 0.88) (0.18f * blurIntensity) else 0f
    }

    fun getFogDensity(): Float {
        if (ClientRoleHolder.getRole() != InjuryRole.BLURRED_VISION) return 0f
        return 0.06f + (blurIntensity * 0.28f)
    }
}

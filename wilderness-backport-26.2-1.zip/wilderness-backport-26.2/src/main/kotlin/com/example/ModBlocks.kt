package com.example

import net.minecraft.core.Registry
import net.minecraft.core.registries.BuiltInRegistries
import net.minecraft.core.registries.Registries
import net.minecraft.resources.ResourceKey
import net.minecraft.world.item.BlockItem
import net.minecraft.world.item.Item
import net.minecraft.world.level.block.Block
import net.minecraft.world.level.block.Blocks
import net.minecraft.world.level.block.SlabBlock
import net.minecraft.world.level.block.SoundType
import net.minecraft.world.level.block.StairBlock
import net.minecraft.world.level.block.state.BlockBehaviour
import net.minecraft.world.level.block.state.properties.NoteBlockInstrument
import net.minecraft.world.level.material.MapColor
import net.minecraft.world.item.DyeColor
import java.util.function.Function

/**
 * Registers a subset of 26.3 "Wilderness Bound" blocks on 26.2.
 * Goal: make the blocks exist in the registry so ViaFabricPlus clients
 * can place / break / hold them (textures will be missing).
 *
 * We deliberately use the vanilla "minecraft" namespace for the IDs
 * so that protocol translation has a better chance of matching.
 */
object ModBlocks {

	// ============ Poplar wood set (basic) ============
	val POPLAR_LOG: Block = register(
		"poplar_log",
		{ props -> Block(props) },
		BlockBehaviour.Properties.of()
			.mapColor(MapColor.COLOR_BROWN)
			.instrument(NoteBlockInstrument.BASS)
			.strength(2.0f)
			.sound(SoundType.WOOD)
			.ignitedByLava()
	)

	val POPLAR_PLANKS: Block = register(
		"poplar_planks",
		{ props -> Block(props) },
		BlockBehaviour.Properties.of()
			.mapColor(MapColor.COLOR_LIGHT_GRAY)
			.instrument(NoteBlockInstrument.BASS)
			.strength(2.0f, 3.0f)
			.sound(SoundType.WOOD)
			.ignitedByLava()
	)

	val POPLAR_STAIRS: Block = register(
		"poplar_stairs",
		{ props -> StairBlock(POPLAR_PLANKS.defaultBlockState(), props) },
		BlockBehaviour.Properties.ofFullCopy(POPLAR_PLANKS)
	)

	val POPLAR_SLAB: Block = register(
		"poplar_slab",
		{ props -> SlabBlock(props) },
		BlockBehaviour.Properties.ofFullCopy(POPLAR_PLANKS)
	)

	val RED_POPLAR_LEAVES: Block = register(
		"red_poplar_leaves",
		{ props -> Block(props) },
		BlockBehaviour.Properties.of()
			.mapColor(MapColor.COLOR_RED)
			.strength(0.2f)
			.sound(SoundType.GRASS)
			.noOcclusion()
			.isSuffocating { _, _, _ -> false }
			.isViewBlocking { _, _, _ -> false }
	)

	val ORANGE_POPLAR_LEAVES: Block = register(
		"orange_poplar_leaves",
		{ props -> Block(props) },
		BlockBehaviour.Properties.of()
			.mapColor(MapColor.COLOR_ORANGE)
			.strength(0.2f)
			.sound(SoundType.GRASS)
			.noOcclusion()
			.isSuffocating { _, _, _ -> false }
			.isViewBlocking { _, _, _ -> false }
	)

	val YELLOW_POPLAR_LEAVES: Block = register(
		"yellow_poplar_leaves",
		{ props -> Block(props) },
		BlockBehaviour.Properties.of()
			.mapColor(MapColor.COLOR_YELLOW)
			.strength(0.2f)
			.sound(SoundType.GRASS)
			.noOcclusion()
			.isSuffocating { _, _, _ -> false }
			.isViewBlocking { _, _, _ -> false }
	)

	val POPLAR_SAPLING: Block = register(
		"poplar_sapling",
		{ props -> Block(props) }, // simple placeholder; no tree growth yet
		BlockBehaviour.Properties.of()
			.mapColor(MapColor.PLANT)
			.noCollision()
			.randomTicks()
			.instabreak()
			.sound(SoundType.GRASS)
	)

	// ============ Wool Stairs & Slabs (16 colours) ============
	val WOOL_STAIRS: Map<DyeColor, Block> = DyeColor.entries.associateWith { color ->
		register(
			"${color.serializedName}_wool_stairs",
			{ props -> StairBlock(Blocks.WHITE_WOOL.defaultBlockState(), props) },
			BlockBehaviour.Properties.of()
				.mapColor(color.mapColor)
				.strength(0.8f)
				.sound(SoundType.WOOL)
				.ignitedByLava()
		)
	}

	val WOOL_SLABS: Map<DyeColor, Block> = DyeColor.entries.associateWith { color ->
		register(
			"${color.serializedName}_wool_slab",
			{ props -> SlabBlock(props) },
			BlockBehaviour.Properties.of()
				.mapColor(color.mapColor)
				.strength(0.8f)
				.sound(SoundType.WOOL)
				.ignitedByLava()
		)
	}

	// ============ Concrete Stairs & Slabs (16 colours) ============
	val CONCRETE_STAIRS: Map<DyeColor, Block> = DyeColor.entries.associateWith { color ->
		register(
			"${color.serializedName}_concrete_stairs",
			{ props -> StairBlock(Blocks.WHITE_CONCRETE.defaultBlockState(), props) },
			BlockBehaviour.Properties.of()
				.mapColor(color.mapColor)
				.requiresCorrectToolForDrops()
				.strength(1.8f)
				.sound(SoundType.STONE)
		)
	}

	val CONCRETE_SLABS: Map<DyeColor, Block> = DyeColor.entries.associateWith { color ->
		register(
			"${color.serializedName}_concrete_slab",
			{ props -> SlabBlock(props) },
			BlockBehaviour.Properties.of()
				.mapColor(color.mapColor)
				.requiresCorrectToolForDrops()
				.strength(1.8f)
				.sound(SoundType.STONE)
		)
	}

	fun register() {
		// Force static initialization of all vals
		listOf(
			POPLAR_LOG, POPLAR_PLANKS, POPLAR_STAIRS, POPLAR_SLAB,
			RED_POPLAR_LEAVES, ORANGE_POPLAR_LEAVES, YELLOW_POPLAR_LEAVES, POPLAR_SAPLING
		)
		WOOL_STAIRS.values
		WOOL_SLABS.values
		CONCRETE_STAIRS.values
		CONCRETE_SLABS.values

		WildernessBackport.LOGGER.info("Registered poplar set + ${WOOL_STAIRS.size * 2 + CONCRETE_STAIRS.size * 2} coloured stairs/slabs")
	}

	private fun register(
		name: String,
		factory: Function<BlockBehaviour.Properties, Block>,
		properties: BlockBehaviour.Properties
	): Block {
		val id = WildernessBackport.vanillaId(name)
		val key = ResourceKey.create(Registries.BLOCK, id)

		// Modern registration style (setId on properties)
		val block = factory.apply(properties.setId(key))

		Registry.register(BuiltInRegistries.BLOCK, key, block)

		// Also register a BlockItem under the same id
		val itemKey = ResourceKey.create(Registries.ITEM, id)
		val item = BlockItem(block, Item.Properties().setId(itemKey))
		Registry.register(BuiltInRegistries.ITEM, itemKey, item)

		return block
	}
}

package com.injuryroles.client.mixin;

import com.injuryroles.client.hud.JumpChargeHud;
import com.injuryroles.network.ClientRoleHolder;
import com.injuryroles.role.InjuryRole;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.world.phys.Vec3;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(LocalPlayer.class)
public class ClientPlayerMixin {

    /**
     * บล็อกการกระโดดปกติของ Broken Leg
     * ให้ใช้ระบบชาร์จแทน
     */
    @Inject(method = "aiStep", at = @At("HEAD"))
    private void onAiStep(CallbackInfo ci) {
        LocalPlayer self = (LocalPlayer) (Object) this;

        if (ClientRoleHolder.INSTANCE.getRole() == InjuryRole.BROKEN_LEG) {
            // ถ้ากำลังชาร์จอยู่ หรือเพิ่งกระโดดไป ห้ามกระโดดซ้ำด้วย input ปกติ
            if (JumpChargeHud.INSTANCE.isChargingJump()) {
                // ปิด jump input ชั่วคราวโดยการเซ็ตค่า
                // (วิธีที่ปลอดภัยกว่าคือจัดการที่ input)
            }
        }
    }
}

package com.example.curse

import net.minecraft.server.level.ServerPlayer
import net.minecraft.world.phys.Vec3
import java.util.UUID
import kotlin.random.Random

/** เก็บอาการและระดับความรุนแรงที่ใช้อยู่ (เก็บในหน่วยความจำ รีสตาร์ทเซิร์ฟเวอร์แล้วหาย) */
object CurseManager {

	private class Active(val curse: Curse, var ticksLeft: Int)

	private val active = mutableMapOf<UUID, MutableList<Active>>()
	private val lastHorizontal = mutableMapOf<UUID, Vec3>()

	/** ระดับความรุนแรงรวมของเซิร์ฟเวอร์ เปลี่ยนได้ด้วย /curse level */
	var level: Level = Level.NORMAL

	/** สุ่มอาการที่ผู้เล่นยังไม่มี ตามน้ำหนัก แล้วคืนค่าอาการที่ได้ (หรือ null ถ้าไม่เหลือให้สุ่ม) */
	fun roll(player: ServerPlayer): Curse? {
		val list = active.getOrPut(player.uuid) { mutableListOf() }
		val current = list.map { it.curse }.toSet()
		val pool = Curse.entries.filter { it !in current }
		if (pool.isEmpty()) return null

		val total = pool.sumOf { it.weight }
		var pick = Random.nextInt(total)
		val chosen = pool.first { c ->
			pick -= c.weight
			pick < 0
		}
		list.add(Active(chosen, chosen.durationTicks))
		return chosen
	}

	fun clear(player: ServerPlayer) {
		active.remove(player.uuid)
		lastHorizontal.remove(player.uuid)
	}

	fun has(player: ServerPlayer, curse: Curse): Boolean =
		active[player.uuid]?.any { it.curse == curse } == true

	fun list(player: ServerPlayer): List<Curse> =
		active[player.uuid]?.map { it.curse } ?: emptyList()

	/** เรียกทุก tick ของเซิร์ฟเวอร์ */
	fun tick(player: ServerPlayer) {
		val list = active[player.uuid] ?: return
		val tick = player.level().gameTime

		list.forEach { it.ticksLeft-- }
		list.removeAll { it.ticksLeft <= 0 }

		if (list.isEmpty()) {
			clear(player)
			return
		}

		val curses = list.map { it.curse }.toSet()
		applyMovement(player, curses)
		applyHealth(player, curses, tick)
		applyControl(player, curses, tick)
	}

	private fun applyControl(player: ServerPlayer, curses: Set<Curse>, tick: Long) {
		if (Curse.DROP_ITEMS in curses && tick % level.interval(200L) == 0L) {
			val inv = player.inventory
			if (!inv.getItem(inv.selected).isEmpty) {
				player.drop(inv.removeItem(inv.selected, 1), false)
			}
		}
		if (Curse.SHUFFLE in curses && tick % level.interval(300L) == 0L) {
			val inv = player.inventory
			val a = Random.nextInt(9)
			val b = Random.nextInt(9)
			val tmp = inv.getItem(a)
			inv.setItem(a, inv.getItem(b))
			inv.setItem(b, tmp)
		}
	}

	private fun applyMovement(player: ServerPlayer, curses: Set<Curse>) {
		val v: Vec3 = player.deltaMovement
		var horizontal = Vec3(v.x, 0.0, v.z)
		var vy = v.y

		if (Curse.BROKEN_LEG in curses) {
			horizontal = horizontal.scale(level.scale(0.35))
			if (vy > 0.0) vy *= level.scale(0.0)
		}
		if (Curse.WEAK_LEGS in curses) {
			horizontal = horizontal.scale(level.scale(0.6))
		}
		if (Curse.HEAVY in curses && vy > 0.0) {
			vy *= level.scale(0.45)
		}
		if (Curse.ICE in curses && player.onGround()) {
			val prev = lastHorizontal[player.uuid] ?: horizontal
			val keep = level.scale(0.85)
			horizontal = prev.scale(keep).add(horizontal.scale(1.0 - keep))
		}
		if (Curse.CONFUSED in curses && Random.nextDouble() < 0.02 * level.severity) {
			horizontal = horizontal.scale(-1.0)
		}
		if (Curse.DRUNK in curses) {
			val angle = Random.nextDouble() * Math.PI * 2
			val push = 0.03 * level.severity
			horizontal = horizontal.add(Vec3(Math.cos(angle) * push, 0.0, Math.sin(angle) * push))
		}

		lastHorizontal[player.uuid] = horizontal
		player.setDeltaMovement(horizontal.x, vy, horizontal.z)
	}

	private fun applyHealth(player: ServerPlayer, curses: Set<Curse>, tick: Long) {
		if (Curse.FEVER in curses && tick % level.interval(60L) == 0L) {
			if (player.health > 1.0f) {
				player.setHealth(player.health - 1.0f)
			}
		}
		if (Curse.HUNGER in curses && tick % level.interval(200L) == 0L) {
			val food = player.foodData
			food.setFoodLevel((food.foodLevel - 1).coerceAtLeast(0))
		}
	}
}

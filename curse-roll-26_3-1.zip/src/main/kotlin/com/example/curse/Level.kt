package com.example.curse

/** ระดับความรุนแรงของอาการ ใช้คูณผลกระทบ */
enum class Level(val displayName: String, val severity: Double) {
	MILD("อ่อน", 0.5),
	NORMAL("ปกติ", 1.0),
	HARSH("หนัก", 1.5);

	/** ค่าตัวคูณที่ได้จากค่าฐาน base (1.0 = ไม่มีผล) ยิ่งหนัก ตัวคูณยิ่งต่ำ */
	fun scale(base: Double): Double =
		(1.0 - (1.0 - base) * severity).coerceIn(0.05, 1.0)

	/** ช่วงเวลาระหว่างการทำงาน (tick) ยิ่งหนัก ยิ่งถี่ */
	fun interval(baseTicks: Long): Long =
		(baseTicks / severity).toLong().coerceAtLeast(1L)

	companion object {
		fun parse(s: String): Level? = entries.firstOrNull { it.name.equals(s, ignoreCase = true) }
	}
}

package com.injuryroles.client

import com.injuryroles.client.hud.JumpChargeHud
import com.injuryroles.client.render.VisionEffects
import com.injuryroles.network.ModNetworking
import net.fabricmc.api.ClientModInitializer
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents
import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback
import net.minecraft.client.Minecraft
import net.minecraft.client.gui.GuiGraphics

object InjuryRolesClient : ClientModInitializer {
    override fun onInitializeClient() {
        ModNetworking.registerClient()
        VisionEffects.register()

        HudRenderCallback.EVENT.register { context, tickCounter ->
            JumpChargeHud.render(context, tickCounter)
            renderVisionOverlay(context)
        }

        ClientTickEvents.END_CLIENT_TICK.register { client ->
            VisionEffects.tick(client)
            JumpChargeHud.tick(client)
        }
    }

    private fun renderVisionOverlay(context: GuiGraphics) {
        val blur = VisionEffects.getBlurIntensity()
        if (blur <= 0.01f) return

        val client = Minecraft.getInstance()
        val w = client.window.guiScaledWidth
        val h = client.window.guiScaledHeight

        // หมอก / vignette แบบง่าย
        val alpha = (blur * 120).toInt().coerceIn(0, 160)
        // มุมมืด ๆ
        context.fill(0, 0, w, 20, (alpha shl 24) or 0x000000)
        context.fill(0, h - 20, w, h, (alpha shl 24) or 0x000000)
        context.fill(0, 0, 30, h, (alpha / 2 shl 24) or 0x000000)
        context.fill(w - 30, 0, w, h, (alpha / 2 shl 24) or 0x000000)

        // วูบวาบ
        val flash = VisionEffects.getFlashAlpha()
        if (flash > 0.01f) {
            val fAlpha = (flash * 255).toInt().coerceIn(0, 80)
            context.fill(0, 0, w, h, (fAlpha shl 24) or 0xFFFFFF)
        }
    }
}
